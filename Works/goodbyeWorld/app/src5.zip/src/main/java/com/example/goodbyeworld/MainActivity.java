package com.example.goodbyeworld;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout we created
        setContentView(R.layout.navigation_bar_layout);

        BottomNavigationView navigationView = findViewById(R.id.bottom_nav);

        navigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id == R.id.action_home) {
                    Toast.makeText(MainActivity.this, "Home", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (id == R.id.action_favourite) {
                    Toast.makeText(MainActivity.this, "Favorite", Toast.LENGTH_SHORT).show();
                    return true;
                } else if (id == R.id.action_my_page) {
                    Toast.makeText(MainActivity.this, "My Page", Toast.LENGTH_SHORT).show();
                    return true;
                }

                return false;
            }
        });
    }
}

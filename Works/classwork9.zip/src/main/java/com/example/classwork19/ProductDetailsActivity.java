package com.example.classwork19;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ProductDetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        ImageView image = findViewById(R.id.imageProduct);
        TextView name = findViewById(R.id.textProductName);
        TextView price = findViewById(R.id.textProductPrice);

        // Get data from intent
        String productName = getIntent().getStringExtra("name");
        String productPrice = getIntent().getStringExtra("price");
        int productImage = getIntent().getIntExtra("image", 0);

        image.setImageResource(productImage);
        name.setText(productName);
        price.setText(productPrice);
    }
}


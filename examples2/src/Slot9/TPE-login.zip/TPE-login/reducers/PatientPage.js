import { useEffect, useReducer, useState } from "react";
import axios from "axios";
import PatientList from "./PatientList";
import PatientForm from "./PatientForm";
import { patientReducer } from "./PatientReducer";

export default function PatientPage() {
  const [patients, dispatch] = useReducer(patientReducer, []);
  const [editingPatient, setEditingPatient] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/patients")
      .then((res) => dispatch({ type: "SET", payload: res.data }));
  }, []);

  const addPatient = (patient) => {
    axios
      .post("http://localhost:5000/patients", patient)
      .then((res) => dispatch({ type: "ADD", payload: res.data }));
  };

  const updatePatient = (patient) => {
    axios
      .put(`http://localhost:5000/patients/${patient.id}`, patient)
      .then((res) => dispatch({ type: "UPDATE", payload: res.data }));
  };

  const deletePatient = (id) => {
    if (window.confirm("Are you sure?")) {
      axios
        .delete(`http://localhost:5000/patients/${id}`)
        .then(() => dispatch({ type: "DELETE", payload: id }));
    }
  };

  return (
    <div className="container">
      <h2>Patient Management</h2>
      <PatientForm
        onSave={editingPatient ? updatePatient : addPatient}
        patient={editingPatient}
      />
      <PatientList
        patients={patients}
        onEdit={setEditingPatient}
        onDelete={deletePatient}
      />
    </div>
  );
}
